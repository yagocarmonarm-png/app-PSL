# PSL SCANNER AI

Versión web instalable (PWA) preparada para publicar en GitHub Pages.

## Contenido
- `index.html`: aplicación original.
- `manifest.webmanifest`: nombre, iconos y ajustes para instalarla como app.
- `service-worker.js`: guarda la carcasa de la web para que pueda abrirse tras la primera carga.
- `icons/`: iconos de la aplicación.

## Publicar gratis con GitHub Pages
1. Inicia sesión en https://github.com/.
2. Crea un repositorio llamado `psl-scanner-ai`. Puede ser público.
3. En el repositorio, usa **Add file → Upload files** y sube TODOS los archivos y carpetas de esta carpeta. No subas solo `index.html`.
4. Pulsa **Commit changes**.
5. Abre **Settings → Pages**.
6. En **Build and deployment**, elige **Deploy from a branch**.
7. Selecciona la rama `main` y la carpeta `/(root)`, y pulsa **Save**.
8. Espera unos minutos. La URL tendrá el formato `https://TUUSUARIO.github.io/psl-scanner-ai/`.

## Instalar en el móvil
- Android (Chrome): abre el enlace publicado, menú ⋮ y elige **Instalar aplicación** o **Añadir a pantalla de inicio**.
- iPhone (Safari): abre el enlace, pulsa Compartir y después **Añadir a pantalla de inicio**.

## Notas importantes
- La primera vez se necesita Internet para descargar MediaPipe y su modelo desde los servicios configurados en la app.
- El service worker almacena la interfaz local; no almacena el modelo de visión ni garantiza que el análisis facial funcione sin conexión.
- Las fotos se procesan en el navegador según el código actual. El historial y los ajustes se guardan en el dispositivo del usuario, no se sincronizan entre dispositivos.
- Las puntuaciones son una estimación de un modelo propio, no una medida científica del atractivo. En el código actual, a menores de 18 años no se les muestra puntuación PSL ni ranking.
- Antes de ofrecerla ampliamente al público, revisa privacidad, consentimiento y normativa aplicable a datos biométricos. No presentes el modelo como validado científicamente.

## Prueba local
Para probar el modo instalable, sirve la carpeta con un servidor local (por ejemplo, VS Code + Live Server). Las PWA requieren HTTPS o localhost.
